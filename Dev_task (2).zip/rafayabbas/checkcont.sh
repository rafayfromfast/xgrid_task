docker ps -a 
docker docker container prune 
