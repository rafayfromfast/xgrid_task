#Official Docker Images are used in Dockerfiles 
#docker-compose is making 3 services using all 3 Dockerfiles
#use docker-compose build to build stack images
#Use docker-compose up to run the stack 
# Now you can verify stack on exposed ports 
#THANKS 
#Raffay Abbas - X-GRID






# Script checks for container all running and stopped 
and prunes all stopped containers
